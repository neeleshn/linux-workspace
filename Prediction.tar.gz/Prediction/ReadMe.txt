------------------------------------
Authors: Habiba Shaik, Neelesh Nidadhavolu
------------------------------------

REQUIRED SOFTWARE, PACKAGES & SETTINGS
=======================================

1. Software
------------- 
 * Oracle JDK version 1.7 or Open JDK 7
 * aws-cli
 * gradle

HOW TO EXECUTE THE PROGRAM
=========================================
1. Copy files of a6history to History/all
2. Copy files of a6test to Test/all
3. Copy files of a6validate to Evaluation/all
4. To run the program in pseudo mode -
	make pseudo
   To run the program in EMR
	make emr

