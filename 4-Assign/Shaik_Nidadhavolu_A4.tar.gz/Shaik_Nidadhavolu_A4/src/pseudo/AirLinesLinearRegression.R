library(ggplot2)
library(caret)
args<-commandArgs(trailingOnly = TRUE)
foldername <- args[1]
setwd(foldername)
files<-list.files(path="/Users/ummehabibashaik/Documents/Mapreduce/HW4/src/pseudo/output/output",pattern="part-r-", full.names = TRUE)
#dir("/Users/ummehabibashaik/Documents/Mapreduce/HW4/src/pseudo/output/", pattern='part-r-', full.names = TRUE)
newData<-c()
for(i in 1:length(files)){
  print(files[i])
  newData <- rbind(newData,read.table(file=files[i], header=FALSE, sep="\t"))
}

#Loading Data
#newData <- read.table(file='part-r-00000', header=FALSE, sep="\t")
colnames(newData) <- c("AIRLINE","AVG_TICKET_PRICE","DISTANCE","CRS_ELAPSED_TIME")

#Data cleansing - removing null values
CleansedData <- na.omit(newData)
CleansedData$CRS_ELAPSED_TIME <- as.integer(CleansedData$CRS_ELAPSED_TIME)
summary(CleansedData)

uniqueList<-unique(CleansedData[c('AIRLINE')])
print(uniqueList,row.names = FALSE)

airline_prices <- data.frame(AIRLINE=character(),PRICE=integer(),stringsAsFactors=FALSE) 
for (airline in uniqueList$AIRLINE){
  
  filteredData <- CleansedData[CleansedData$AIRLINE == airline,]
  
  #Model1: Training Linear model with Distance
  plot.x <- qplot(y=AVG_TICKET_PRICE, x=DISTANCE, data=filteredData)
  model.x <- lm(AVG_TICKET_PRICE ~ DISTANCE, filteredData)
  prices <- predict(model.x,data.frame(DISTANCE=(c(100,500,1000))),interval="prediction")
  airline_prices <- rbind(airline_prices,data.frame("AIRLINE"=airline, "PRICE"=sum(prices[,"fit"])))
  coef(model.x)
  plt<-plot.x + geom_abline(intercept=coef(model.x)[1],slope=coef(model.x)[2],col='red')+ xlab("Distance")+ ylab("Ticket Price")
  #ggsave(filename = paste(airline,"_dist",".png",sep=""),plot=plt)
  
  #Model2 Training Linear model with CRS_ELAPSED_TIME
  plot.x2 <- qplot(y=AVG_TICKET_PRICE, x=CRS_ELAPSED_TIME, data=filteredData)
  model.x2 <- lm(AVG_TICKET_PRICE ~ CRS_ELAPSED_TIME, filteredData)
  coef(model.x2)
  plt2 <- plot.x2 + geom_abline(intercept=coef(model.x2)[1],slope=coef(model.x2)[2],col='red')+ xlab("CRS_ELAPSED_TIME")+ ylab("AVG_TICKET_PRICE")
  #ggsave(filename = paste(airline,"_time",".png",sep=""),plot=plt2)
  
}

sortedList<-airline_prices[order(airline_prices$PRICE,decreasing=FALSE),]
cheapAirline <- head(sortedList[1],1)
print(cheapAirline,row.names=FALSE)

summary(model.x2)$r.squared





